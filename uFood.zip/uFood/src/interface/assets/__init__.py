"""Asset package for image files and pickle storage."""
